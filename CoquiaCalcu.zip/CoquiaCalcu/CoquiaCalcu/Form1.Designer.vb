﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Calculator
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Calculator))
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button7 = New System.Windows.Forms.Button()
        Me.Button8 = New System.Windows.Forms.Button()
        Me.Button9 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button14 = New System.Windows.Forms.Button()
        Me.Button15 = New System.Windows.Forms.Button()
        Me.Button16 = New System.Windows.Forms.Button()
        Me.Button17 = New System.Windows.Forms.Button()
        Me.Button18 = New System.Windows.Forms.Button()
        Me.Button19 = New System.Windows.Forms.Button()
        Me.Button20 = New System.Windows.Forms.Button()
        Me.Button21 = New System.Windows.Forms.Button()
        Me.Button22 = New System.Windows.Forms.Button()
        Me.Button23 = New System.Windows.Forms.Button()
        Me.Button24 = New System.Windows.Forms.Button()
        Me.Button25 = New System.Windows.Forms.Button()
        Me.Button26 = New System.Windows.Forms.Button()
        Me.Button27 = New System.Windows.Forms.Button()
        Me.Button28 = New System.Windows.Forms.Button()
        Me.Button29 = New System.Windows.Forms.Button()
        Me.Button30 = New System.Windows.Forms.Button()
        Me.Button31 = New System.Windows.Forms.Button()
        Me.Button32 = New System.Windows.Forms.Button()
        Me.Button33 = New System.Windows.Forms.Button()
        Me.Button34 = New System.Windows.Forms.Button()
        Me.Button35 = New System.Windows.Forms.Button()
        Me.Button36 = New System.Windows.Forms.Button()
        Me.Button37 = New System.Windows.Forms.Button()
        Me.Button38 = New System.Windows.Forms.Button()
        Me.Button39 = New System.Windows.Forms.Button()
        Me.Button40 = New System.Windows.Forms.Button()
        Me.Button41 = New System.Windows.Forms.Button()
        Me.Button42 = New System.Windows.Forms.Button()
        Me.Button43 = New System.Windows.Forms.Button()
        Me.Button44 = New System.Windows.Forms.Button()
        Me.Button45 = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.Button46 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button1.BackColor = System.Drawing.SystemColors.Control
        Me.Button1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button1.CausesValidation = False
        Me.Button1.FlatAppearance.BorderSize = 0
        Me.Button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button1.Location = New System.Drawing.Point(3, 470)
        Me.Button1.Margin = New System.Windows.Forms.Padding(1)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(61, 44)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "("
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button2
        '
        Me.Button2.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button2.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button2.BackColor = System.Drawing.SystemColors.Control
        Me.Button2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button2.CausesValidation = False
        Me.Button2.FlatAppearance.BorderSize = 0
        Me.Button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button2.Location = New System.Drawing.Point(66, 470)
        Me.Button2.Margin = New System.Windows.Forms.Padding(1)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(61, 44)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = ")"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button3.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button3.BackColor = System.Drawing.SystemColors.Window
        Me.Button3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button3.CausesValidation = False
        Me.Button3.FlatAppearance.BorderSize = 0
        Me.Button3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button3.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button3.Location = New System.Drawing.Point(129, 470)
        Me.Button3.Margin = New System.Windows.Forms.Padding(1)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(61, 44)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "0"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'Button5
        '
        Me.Button5.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button5.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button5.BackColor = System.Drawing.SystemColors.Control
        Me.Button5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button5.CausesValidation = False
        Me.Button5.FlatAppearance.BorderSize = 0
        Me.Button5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSkyBlue
        Me.Button5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DodgerBlue
        Me.Button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button5.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button5.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button5.Location = New System.Drawing.Point(255, 470)
        Me.Button5.Margin = New System.Windows.Forms.Padding(1)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(61, 44)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "="
        Me.Button5.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button4.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button4.BackColor = System.Drawing.SystemColors.Control
        Me.Button4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button4.CausesValidation = False
        Me.Button4.FlatAppearance.BorderSize = 0
        Me.Button4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button4.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button4.Location = New System.Drawing.Point(192, 470)
        Me.Button4.Margin = New System.Windows.Forms.Padding(1)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(61, 44)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "."
        Me.Button4.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button6.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button6.BackColor = System.Drawing.SystemColors.Control
        Me.Button6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button6.CausesValidation = False
        Me.Button6.FlatAppearance.BorderSize = 0
        Me.Button6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button6.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button6.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button6.Location = New System.Drawing.Point(3, 424)
        Me.Button6.Margin = New System.Windows.Forms.Padding(1)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(61, 44)
        Me.Button6.TabIndex = 5
        Me.Button6.Text = "±"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'Button7
        '
        Me.Button7.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button7.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button7.BackColor = System.Drawing.SystemColors.Window
        Me.Button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button7.CausesValidation = False
        Me.Button7.FlatAppearance.BorderSize = 0
        Me.Button7.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button7.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button7.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button7.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button7.Location = New System.Drawing.Point(66, 424)
        Me.Button7.Margin = New System.Windows.Forms.Padding(1)
        Me.Button7.Name = "Button7"
        Me.Button7.Size = New System.Drawing.Size(61, 44)
        Me.Button7.TabIndex = 6
        Me.Button7.Text = "1"
        Me.Button7.UseVisualStyleBackColor = False
        '
        'Button8
        '
        Me.Button8.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button8.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button8.BackColor = System.Drawing.SystemColors.Window
        Me.Button8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button8.CausesValidation = False
        Me.Button8.FlatAppearance.BorderSize = 0
        Me.Button8.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button8.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button8.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button8.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button8.Location = New System.Drawing.Point(129, 424)
        Me.Button8.Margin = New System.Windows.Forms.Padding(1)
        Me.Button8.Name = "Button8"
        Me.Button8.Size = New System.Drawing.Size(61, 44)
        Me.Button8.TabIndex = 7
        Me.Button8.Text = "2"
        Me.Button8.UseVisualStyleBackColor = False
        '
        'Button9
        '
        Me.Button9.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button9.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button9.BackColor = System.Drawing.SystemColors.Window
        Me.Button9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button9.CausesValidation = False
        Me.Button9.FlatAppearance.BorderSize = 0
        Me.Button9.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button9.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button9.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button9.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button9.Location = New System.Drawing.Point(192, 424)
        Me.Button9.Margin = New System.Windows.Forms.Padding(1)
        Me.Button9.Name = "Button9"
        Me.Button9.Size = New System.Drawing.Size(61, 44)
        Me.Button9.TabIndex = 8
        Me.Button9.Text = "3"
        Me.Button9.UseVisualStyleBackColor = False
        '
        'Button10
        '
        Me.Button10.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button10.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button10.BackColor = System.Drawing.SystemColors.Control
        Me.Button10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button10.CausesValidation = False
        Me.Button10.FlatAppearance.BorderSize = 0
        Me.Button10.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSkyBlue
        Me.Button10.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DodgerBlue
        Me.Button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button10.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button10.Location = New System.Drawing.Point(255, 424)
        Me.Button10.Margin = New System.Windows.Forms.Padding(1)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(61, 44)
        Me.Button10.TabIndex = 9
        Me.Button10.Text = "+"
        Me.Button10.UseVisualStyleBackColor = False
        '
        'Button11
        '
        Me.Button11.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button11.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button11.BackColor = System.Drawing.SystemColors.Control
        Me.Button11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button11.CausesValidation = False
        Me.Button11.FlatAppearance.BorderSize = 0
        Me.Button11.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button11.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button11.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button11.Location = New System.Drawing.Point(3, 378)
        Me.Button11.Margin = New System.Windows.Forms.Padding(1)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(61, 44)
        Me.Button11.TabIndex = 10
        Me.Button11.Text = "n!"
        Me.Button11.UseVisualStyleBackColor = False
        '
        'Button12
        '
        Me.Button12.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button12.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button12.BackColor = System.Drawing.SystemColors.Window
        Me.Button12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button12.CausesValidation = False
        Me.Button12.FlatAppearance.BorderSize = 0
        Me.Button12.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button12.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button12.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button12.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button12.Location = New System.Drawing.Point(66, 378)
        Me.Button12.Margin = New System.Windows.Forms.Padding(1)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(61, 44)
        Me.Button12.TabIndex = 11
        Me.Button12.Text = "4"
        Me.Button12.UseVisualStyleBackColor = False
        '
        'Button13
        '
        Me.Button13.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button13.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button13.BackColor = System.Drawing.SystemColors.Window
        Me.Button13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button13.CausesValidation = False
        Me.Button13.FlatAppearance.BorderSize = 0
        Me.Button13.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button13.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button13.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button13.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button13.Location = New System.Drawing.Point(129, 378)
        Me.Button13.Margin = New System.Windows.Forms.Padding(1)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(61, 44)
        Me.Button13.TabIndex = 12
        Me.Button13.Text = "5"
        Me.Button13.UseVisualStyleBackColor = False
        '
        'Button14
        '
        Me.Button14.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button14.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button14.BackColor = System.Drawing.SystemColors.Window
        Me.Button14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button14.CausesValidation = False
        Me.Button14.FlatAppearance.BorderSize = 0
        Me.Button14.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button14.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button14.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button14.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button14.Location = New System.Drawing.Point(192, 378)
        Me.Button14.Margin = New System.Windows.Forms.Padding(1)
        Me.Button14.Name = "Button14"
        Me.Button14.Size = New System.Drawing.Size(61, 44)
        Me.Button14.TabIndex = 13
        Me.Button14.Text = "6"
        Me.Button14.UseVisualStyleBackColor = False
        '
        'Button15
        '
        Me.Button15.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button15.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button15.BackColor = System.Drawing.SystemColors.Control
        Me.Button15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button15.CausesValidation = False
        Me.Button15.FlatAppearance.BorderSize = 0
        Me.Button15.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSkyBlue
        Me.Button15.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DodgerBlue
        Me.Button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button15.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button15.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button15.Location = New System.Drawing.Point(255, 378)
        Me.Button15.Margin = New System.Windows.Forms.Padding(1)
        Me.Button15.Name = "Button15"
        Me.Button15.Size = New System.Drawing.Size(61, 44)
        Me.Button15.TabIndex = 14
        Me.Button15.Text = "-"
        Me.Button15.UseVisualStyleBackColor = False
        '
        'Button16
        '
        Me.Button16.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button16.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button16.BackColor = System.Drawing.SystemColors.Control
        Me.Button16.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button16.CausesValidation = False
        Me.Button16.FlatAppearance.BorderSize = 0
        Me.Button16.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button16.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button16.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button16.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button16.Location = New System.Drawing.Point(255, 240)
        Me.Button16.Margin = New System.Windows.Forms.Padding(1)
        Me.Button16.Name = "Button16"
        Me.Button16.Size = New System.Drawing.Size(61, 44)
        Me.Button16.TabIndex = 29
        Me.Button16.Text = "Mod"
        Me.Button16.UseVisualStyleBackColor = False
        '
        'Button17
        '
        Me.Button17.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button17.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button17.BackColor = System.Drawing.SystemColors.Control
        Me.Button17.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button17.CausesValidation = False
        Me.Button17.FlatAppearance.BorderSize = 0
        Me.Button17.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button17.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button17.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button17.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button17.Location = New System.Drawing.Point(192, 240)
        Me.Button17.Margin = New System.Windows.Forms.Padding(1)
        Me.Button17.Name = "Button17"
        Me.Button17.Size = New System.Drawing.Size(61, 44)
        Me.Button17.TabIndex = 28
        Me.Button17.Text = "Exp"
        Me.Button17.UseVisualStyleBackColor = False
        '
        'Button18
        '
        Me.Button18.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button18.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button18.BackColor = System.Drawing.SystemColors.Control
        Me.Button18.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button18.CausesValidation = False
        Me.Button18.FlatAppearance.BorderSize = 0
        Me.Button18.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button18.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button18.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button18.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button18.Location = New System.Drawing.Point(129, 240)
        Me.Button18.Margin = New System.Windows.Forms.Padding(1)
        Me.Button18.Name = "Button18"
        Me.Button18.Size = New System.Drawing.Size(61, 44)
        Me.Button18.TabIndex = 27
        Me.Button18.Text = "log"
        Me.Button18.UseVisualStyleBackColor = False
        '
        'Button19
        '
        Me.Button19.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button19.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button19.BackColor = System.Drawing.SystemColors.Control
        Me.Button19.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button19.CausesValidation = False
        Me.Button19.FlatAppearance.BorderSize = 0
        Me.Button19.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button19.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button19.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button19.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button19.Location = New System.Drawing.Point(66, 240)
        Me.Button19.Margin = New System.Windows.Forms.Padding(1)
        Me.Button19.Name = "Button19"
        Me.Button19.Size = New System.Drawing.Size(61, 44)
        Me.Button19.TabIndex = 26
        Me.Button19.Text = "10^x"
        Me.Button19.UseVisualStyleBackColor = False
        '
        'Button20
        '
        Me.Button20.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button20.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button20.BackColor = System.Drawing.SystemColors.Control
        Me.Button20.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button20.CausesValidation = False
        Me.Button20.FlatAppearance.BorderSize = 0
        Me.Button20.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button20.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button20.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button20.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button20.Location = New System.Drawing.Point(3, 240)
        Me.Button20.Margin = New System.Windows.Forms.Padding(1)
        Me.Button20.Name = "Button20"
        Me.Button20.Size = New System.Drawing.Size(61, 44)
        Me.Button20.TabIndex = 25
        Me.Button20.Text = "√x"
        Me.Button20.UseVisualStyleBackColor = False
        '
        'Button21
        '
        Me.Button21.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button21.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button21.BackColor = System.Drawing.SystemColors.Control
        Me.Button21.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button21.CausesValidation = False
        Me.Button21.FlatAppearance.BorderSize = 0
        Me.Button21.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSkyBlue
        Me.Button21.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DodgerBlue
        Me.Button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button21.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button21.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button21.Location = New System.Drawing.Point(255, 286)
        Me.Button21.Margin = New System.Windows.Forms.Padding(1)
        Me.Button21.Name = "Button21"
        Me.Button21.Size = New System.Drawing.Size(61, 44)
        Me.Button21.TabIndex = 24
        Me.Button21.Text = "÷"
        Me.Button21.UseVisualStyleBackColor = False
        '
        'Button22
        '
        Me.Button22.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button22.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button22.BackColor = System.Drawing.SystemColors.Control
        Me.Button22.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button22.CausesValidation = False
        Me.Button22.FlatAppearance.BorderSize = 0
        Me.Button22.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button22.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button22.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button22.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button22.Location = New System.Drawing.Point(192, 286)
        Me.Button22.Margin = New System.Windows.Forms.Padding(1)
        Me.Button22.Name = "Button22"
        Me.Button22.Size = New System.Drawing.Size(61, 44)
        Me.Button22.TabIndex = 23
        Me.Button22.Text = "⌫"
        Me.Button22.UseVisualStyleBackColor = False
        '
        'Button23
        '
        Me.Button23.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button23.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button23.BackColor = System.Drawing.SystemColors.Control
        Me.Button23.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button23.CausesValidation = False
        Me.Button23.FlatAppearance.BorderSize = 0
        Me.Button23.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button23.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button23.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button23.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button23.Location = New System.Drawing.Point(129, 286)
        Me.Button23.Margin = New System.Windows.Forms.Padding(1)
        Me.Button23.Name = "Button23"
        Me.Button23.Size = New System.Drawing.Size(61, 44)
        Me.Button23.TabIndex = 22
        Me.Button23.Text = "C"
        Me.Button23.UseVisualStyleBackColor = False
        '
        'Button24
        '
        Me.Button24.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button24.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button24.BackColor = System.Drawing.SystemColors.Control
        Me.Button24.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button24.CausesValidation = False
        Me.Button24.FlatAppearance.BorderSize = 0
        Me.Button24.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button24.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button24.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button24.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button24.Location = New System.Drawing.Point(66, 286)
        Me.Button24.Margin = New System.Windows.Forms.Padding(1)
        Me.Button24.Name = "Button24"
        Me.Button24.Size = New System.Drawing.Size(61, 44)
        Me.Button24.TabIndex = 21
        Me.Button24.Text = "CE"
        Me.Button24.UseVisualStyleBackColor = False
        '
        'Button25
        '
        Me.Button25.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button25.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button25.BackColor = System.Drawing.SystemColors.Control
        Me.Button25.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button25.CausesValidation = False
        Me.Button25.FlatAppearance.BorderSize = 0
        Me.Button25.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button25.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button25.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button25.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button25.Location = New System.Drawing.Point(3, 286)
        Me.Button25.Margin = New System.Windows.Forms.Padding(1)
        Me.Button25.Name = "Button25"
        Me.Button25.Size = New System.Drawing.Size(61, 44)
        Me.Button25.TabIndex = 20
        Me.Button25.Text = "2nd"
        Me.Button25.UseVisualStyleBackColor = False
        '
        'Button26
        '
        Me.Button26.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button26.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button26.BackColor = System.Drawing.SystemColors.Control
        Me.Button26.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button26.CausesValidation = False
        Me.Button26.FlatAppearance.BorderSize = 0
        Me.Button26.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightSkyBlue
        Me.Button26.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DodgerBlue
        Me.Button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button26.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button26.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button26.Location = New System.Drawing.Point(255, 332)
        Me.Button26.Margin = New System.Windows.Forms.Padding(1)
        Me.Button26.Name = "Button26"
        Me.Button26.Size = New System.Drawing.Size(61, 44)
        Me.Button26.TabIndex = 19
        Me.Button26.Text = "X"
        Me.Button26.UseVisualStyleBackColor = False
        '
        'Button27
        '
        Me.Button27.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button27.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button27.BackColor = System.Drawing.SystemColors.Window
        Me.Button27.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button27.CausesValidation = False
        Me.Button27.FlatAppearance.BorderSize = 0
        Me.Button27.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button27.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button27.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button27.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button27.Location = New System.Drawing.Point(192, 332)
        Me.Button27.Margin = New System.Windows.Forms.Padding(1)
        Me.Button27.Name = "Button27"
        Me.Button27.Size = New System.Drawing.Size(61, 44)
        Me.Button27.TabIndex = 18
        Me.Button27.Text = "9"
        Me.Button27.UseVisualStyleBackColor = False
        '
        'Button28
        '
        Me.Button28.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button28.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button28.BackColor = System.Drawing.SystemColors.Window
        Me.Button28.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button28.CausesValidation = False
        Me.Button28.FlatAppearance.BorderSize = 0
        Me.Button28.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button28.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button28.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button28.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button28.Location = New System.Drawing.Point(129, 332)
        Me.Button28.Margin = New System.Windows.Forms.Padding(1)
        Me.Button28.Name = "Button28"
        Me.Button28.Size = New System.Drawing.Size(61, 44)
        Me.Button28.TabIndex = 17
        Me.Button28.Text = "8"
        Me.Button28.UseVisualStyleBackColor = False
        '
        'Button29
        '
        Me.Button29.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button29.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button29.BackColor = System.Drawing.SystemColors.Window
        Me.Button29.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button29.CausesValidation = False
        Me.Button29.FlatAppearance.BorderSize = 0
        Me.Button29.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button29.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button29.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button29.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button29.Location = New System.Drawing.Point(66, 332)
        Me.Button29.Margin = New System.Windows.Forms.Padding(1)
        Me.Button29.Name = "Button29"
        Me.Button29.Size = New System.Drawing.Size(61, 44)
        Me.Button29.TabIndex = 16
        Me.Button29.Text = "7"
        Me.Button29.UseVisualStyleBackColor = False
        '
        'Button30
        '
        Me.Button30.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button30.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button30.BackColor = System.Drawing.SystemColors.Control
        Me.Button30.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button30.CausesValidation = False
        Me.Button30.FlatAppearance.BorderSize = 0
        Me.Button30.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button30.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button30.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button30.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button30.Location = New System.Drawing.Point(3, 332)
        Me.Button30.Margin = New System.Windows.Forms.Padding(1)
        Me.Button30.Name = "Button30"
        Me.Button30.Size = New System.Drawing.Size(61, 44)
        Me.Button30.TabIndex = 15
        Me.Button30.Text = "π"
        Me.Button30.UseVisualStyleBackColor = False
        '
        'Button31
        '
        Me.Button31.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button31.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button31.BackColor = System.Drawing.SystemColors.Control
        Me.Button31.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button31.CausesValidation = False
        Me.Button31.FlatAppearance.BorderSize = 0
        Me.Button31.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button31.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button31.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button31.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button31.Location = New System.Drawing.Point(255, 194)
        Me.Button31.Margin = New System.Windows.Forms.Padding(1)
        Me.Button31.Name = "Button31"
        Me.Button31.Size = New System.Drawing.Size(61, 44)
        Me.Button31.TabIndex = 34
        Me.Button31.Text = "tan"
        Me.Button31.UseVisualStyleBackColor = False
        '
        'Button32
        '
        Me.Button32.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button32.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button32.BackColor = System.Drawing.SystemColors.Control
        Me.Button32.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button32.CausesValidation = False
        Me.Button32.FlatAppearance.BorderSize = 0
        Me.Button32.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button32.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button32.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button32.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button32.Location = New System.Drawing.Point(192, 194)
        Me.Button32.Margin = New System.Windows.Forms.Padding(1)
        Me.Button32.Name = "Button32"
        Me.Button32.Size = New System.Drawing.Size(61, 44)
        Me.Button32.TabIndex = 33
        Me.Button32.Text = "cos"
        Me.Button32.UseVisualStyleBackColor = False
        '
        'Button33
        '
        Me.Button33.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button33.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button33.BackColor = System.Drawing.SystemColors.Control
        Me.Button33.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button33.CausesValidation = False
        Me.Button33.FlatAppearance.BorderSize = 0
        Me.Button33.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button33.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button33.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button33.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button33.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button33.Location = New System.Drawing.Point(129, 194)
        Me.Button33.Margin = New System.Windows.Forms.Padding(1)
        Me.Button33.Name = "Button33"
        Me.Button33.Size = New System.Drawing.Size(61, 44)
        Me.Button33.TabIndex = 32
        Me.Button33.Text = "sin"
        Me.Button33.UseVisualStyleBackColor = False
        '
        'Button34
        '
        Me.Button34.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button34.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button34.BackColor = System.Drawing.SystemColors.Control
        Me.Button34.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button34.CausesValidation = False
        Me.Button34.FlatAppearance.BorderSize = 0
        Me.Button34.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button34.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button34.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button34.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button34.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button34.Location = New System.Drawing.Point(66, 194)
        Me.Button34.Margin = New System.Windows.Forms.Padding(1)
        Me.Button34.Name = "Button34"
        Me.Button34.Size = New System.Drawing.Size(61, 44)
        Me.Button34.TabIndex = 31
        Me.Button34.Text = "x^y"
        Me.Button34.UseVisualStyleBackColor = False
        '
        'Button35
        '
        Me.Button35.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button35.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button35.BackColor = System.Drawing.SystemColors.Control
        Me.Button35.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button35.CausesValidation = False
        Me.Button35.FlatAppearance.BorderSize = 0
        Me.Button35.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button35.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button35.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button35.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button35.Location = New System.Drawing.Point(3, 194)
        Me.Button35.Margin = New System.Windows.Forms.Padding(1)
        Me.Button35.Name = "Button35"
        Me.Button35.Size = New System.Drawing.Size(61, 44)
        Me.Button35.TabIndex = 30
        Me.Button35.Text = "x^2"
        Me.Button35.UseVisualStyleBackColor = False
        '
        'Button36
        '
        Me.Button36.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button36.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button36.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Button36.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button36.CausesValidation = False
        Me.Button36.FlatAppearance.BorderSize = 0
        Me.Button36.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button36.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button36.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button36.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button36.Location = New System.Drawing.Point(211, 158)
        Me.Button36.Margin = New System.Windows.Forms.Padding(1)
        Me.Button36.Name = "Button36"
        Me.Button36.Size = New System.Drawing.Size(50, 30)
        Me.Button36.TabIndex = 39
        Me.Button36.Text = "MS"
        Me.Button36.UseVisualStyleBackColor = False
        '
        'Button37
        '
        Me.Button37.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button37.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button37.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Button37.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button37.CausesValidation = False
        Me.Button37.FlatAppearance.BorderSize = 0
        Me.Button37.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button37.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button37.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button37.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button37.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button37.Location = New System.Drawing.Point(159, 158)
        Me.Button37.Margin = New System.Windows.Forms.Padding(1)
        Me.Button37.Name = "Button37"
        Me.Button37.Size = New System.Drawing.Size(50, 30)
        Me.Button37.TabIndex = 38
        Me.Button37.Text = "M-"
        Me.Button37.UseVisualStyleBackColor = False
        '
        'Button38
        '
        Me.Button38.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button38.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button38.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Button38.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button38.CausesValidation = False
        Me.Button38.FlatAppearance.BorderSize = 0
        Me.Button38.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button38.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button38.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button38.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button38.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button38.Location = New System.Drawing.Point(107, 158)
        Me.Button38.Margin = New System.Windows.Forms.Padding(1)
        Me.Button38.Name = "Button38"
        Me.Button38.Size = New System.Drawing.Size(50, 30)
        Me.Button38.TabIndex = 37
        Me.Button38.Text = "M+"
        Me.Button38.UseVisualStyleBackColor = False
        '
        'Button39
        '
        Me.Button39.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button39.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button39.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Button39.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button39.CausesValidation = False
        Me.Button39.Enabled = False
        Me.Button39.FlatAppearance.BorderSize = 0
        Me.Button39.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button39.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button39.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button39.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button39.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button39.Location = New System.Drawing.Point(55, 158)
        Me.Button39.Margin = New System.Windows.Forms.Padding(1)
        Me.Button39.Name = "Button39"
        Me.Button39.Size = New System.Drawing.Size(50, 30)
        Me.Button39.TabIndex = 36
        Me.Button39.Text = "MR"
        Me.Button39.UseVisualStyleBackColor = False
        '
        'Button40
        '
        Me.Button40.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button40.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button40.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Button40.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button40.CausesValidation = False
        Me.Button40.Enabled = False
        Me.Button40.FlatAppearance.BorderSize = 0
        Me.Button40.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button40.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button40.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button40.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button40.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button40.Location = New System.Drawing.Point(3, 158)
        Me.Button40.Margin = New System.Windows.Forms.Padding(1)
        Me.Button40.Name = "Button40"
        Me.Button40.Size = New System.Drawing.Size(50, 30)
        Me.Button40.TabIndex = 35
        Me.Button40.Text = "MC"
        Me.Button40.UseVisualStyleBackColor = False
        '
        'Button41
        '
        Me.Button41.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button41.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button41.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Button41.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button41.CausesValidation = False
        Me.Button41.FlatAppearance.BorderSize = 0
        Me.Button41.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button41.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button41.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button41.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button41.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button41.Location = New System.Drawing.Point(129, 127)
        Me.Button41.Margin = New System.Windows.Forms.Padding(1)
        Me.Button41.Name = "Button41"
        Me.Button41.Size = New System.Drawing.Size(50, 30)
        Me.Button41.TabIndex = 42
        Me.Button41.Text = "F-E"
        Me.Button41.UseVisualStyleBackColor = False
        '
        'Button42
        '
        Me.Button42.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button42.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button42.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Button42.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button42.CausesValidation = False
        Me.Button42.FlatAppearance.BorderSize = 0
        Me.Button42.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button42.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button42.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button42.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button42.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button42.Location = New System.Drawing.Point(66, 127)
        Me.Button42.Margin = New System.Windows.Forms.Padding(1)
        Me.Button42.Name = "Button42"
        Me.Button42.Size = New System.Drawing.Size(50, 30)
        Me.Button42.TabIndex = 41
        Me.Button42.Text = "HYP"
        Me.Button42.UseVisualStyleBackColor = False
        '
        'Button43
        '
        Me.Button43.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button43.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button43.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Button43.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button43.CausesValidation = False
        Me.Button43.FlatAppearance.BorderSize = 0
        Me.Button43.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button43.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button43.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button43.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button43.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button43.Location = New System.Drawing.Point(3, 127)
        Me.Button43.Margin = New System.Windows.Forms.Padding(1)
        Me.Button43.Name = "Button43"
        Me.Button43.Size = New System.Drawing.Size(50, 30)
        Me.Button43.TabIndex = 40
        Me.Button43.Text = "DEG"
        Me.Button43.UseVisualStyleBackColor = False
        '
        'Button44
        '
        Me.Button44.AccessibleRole = System.Windows.Forms.AccessibleRole.PushButton
        Me.Button44.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Button44.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Button44.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Button44.CausesValidation = False
        Me.Button44.Enabled = False
        Me.Button44.FlatAppearance.BorderSize = 0
        Me.Button44.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button44.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button44.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button44.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button44.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Button44.Location = New System.Drawing.Point(261, 158)
        Me.Button44.Margin = New System.Windows.Forms.Padding(1)
        Me.Button44.Name = "Button44"
        Me.Button44.Size = New System.Drawing.Size(50, 30)
        Me.Button44.TabIndex = 43
        Me.Button44.Text = "M˅"
        Me.Button44.UseVisualStyleBackColor = False
        '
        'Button45
        '
        Me.Button45.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control
        Me.Button45.FlatAppearance.BorderSize = 0
        Me.Button45.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button45.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button45.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button45.Location = New System.Drawing.Point(3, 2)
        Me.Button45.Name = "Button45"
        Me.Button45.Size = New System.Drawing.Size(35, 35)
        Me.Button45.TabIndex = 44
        Me.Button45.Text = "☰"
        Me.Button45.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(43, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(84, 24)
        Me.Label1.TabIndex = 45
        Me.Label1.Text = "Scientific"
        '
        'TextBox1
        '
        Me.TextBox1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.TextBox1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(10, 77)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(299, 37)
        Me.TextBox1.TabIndex = 46
        Me.TextBox1.Text = "0"
        Me.TextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'TextBox2
        '
        Me.TextBox2.BackColor = System.Drawing.SystemColors.ControlLight
        Me.TextBox2.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(10, 49)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(299, 15)
        Me.TextBox2.TabIndex = 47
        Me.TextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Button46
        '
        Me.Button46.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.Button46.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control
        Me.Button46.FlatAppearance.BorderSize = 0
        Me.Button46.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Gray
        Me.Button46.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Silver
        Me.Button46.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button46.Image = CType(resources.GetObject("Button46.Image"), System.Drawing.Image)
        Me.Button46.Location = New System.Drawing.Point(281, 2)
        Me.Button46.Name = "Button46"
        Me.Button46.Size = New System.Drawing.Size(35, 35)
        Me.Button46.TabIndex = 48
        Me.Button46.UseCompatibleTextRendering = True
        Me.Button46.UseVisualStyleBackColor = True
        '
        'Calculator
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ControlLight
        Me.ClientSize = New System.Drawing.Size(321, 518)
        Me.Controls.Add(Me.Button46)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Button45)
        Me.Controls.Add(Me.Button44)
        Me.Controls.Add(Me.Button41)
        Me.Controls.Add(Me.Button42)
        Me.Controls.Add(Me.Button43)
        Me.Controls.Add(Me.Button36)
        Me.Controls.Add(Me.Button37)
        Me.Controls.Add(Me.Button38)
        Me.Controls.Add(Me.Button39)
        Me.Controls.Add(Me.Button40)
        Me.Controls.Add(Me.Button31)
        Me.Controls.Add(Me.Button32)
        Me.Controls.Add(Me.Button33)
        Me.Controls.Add(Me.Button34)
        Me.Controls.Add(Me.Button35)
        Me.Controls.Add(Me.Button16)
        Me.Controls.Add(Me.Button17)
        Me.Controls.Add(Me.Button18)
        Me.Controls.Add(Me.Button19)
        Me.Controls.Add(Me.Button20)
        Me.Controls.Add(Me.Button21)
        Me.Controls.Add(Me.Button22)
        Me.Controls.Add(Me.Button23)
        Me.Controls.Add(Me.Button24)
        Me.Controls.Add(Me.Button25)
        Me.Controls.Add(Me.Button26)
        Me.Controls.Add(Me.Button27)
        Me.Controls.Add(Me.Button28)
        Me.Controls.Add(Me.Button29)
        Me.Controls.Add(Me.Button30)
        Me.Controls.Add(Me.Button15)
        Me.Controls.Add(Me.Button14)
        Me.Controls.Add(Me.Button13)
        Me.Controls.Add(Me.Button12)
        Me.Controls.Add(Me.Button11)
        Me.Controls.Add(Me.Button10)
        Me.Controls.Add(Me.Button9)
        Me.Controls.Add(Me.Button8)
        Me.Controls.Add(Me.Button7)
        Me.Controls.Add(Me.Button6)
        Me.Controls.Add(Me.Button5)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.HelpButton = True
        Me.Name = "Calculator"
        Me.ShowIcon = False
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Calculator"
        Me.TransparencyKey = System.Drawing.Color.HotPink
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button7 As System.Windows.Forms.Button
    Friend WithEvents Button8 As System.Windows.Forms.Button
    Friend WithEvents Button9 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Button14 As System.Windows.Forms.Button
    Friend WithEvents Button15 As System.Windows.Forms.Button
    Friend WithEvents Button16 As System.Windows.Forms.Button
    Friend WithEvents Button17 As System.Windows.Forms.Button
    Friend WithEvents Button18 As System.Windows.Forms.Button
    Friend WithEvents Button19 As System.Windows.Forms.Button
    Friend WithEvents Button20 As System.Windows.Forms.Button
    Friend WithEvents Button21 As System.Windows.Forms.Button
    Friend WithEvents Button22 As System.Windows.Forms.Button
    Friend WithEvents Button23 As System.Windows.Forms.Button
    Friend WithEvents Button24 As System.Windows.Forms.Button
    Friend WithEvents Button25 As System.Windows.Forms.Button
    Friend WithEvents Button26 As System.Windows.Forms.Button
    Friend WithEvents Button27 As System.Windows.Forms.Button
    Friend WithEvents Button28 As System.Windows.Forms.Button
    Friend WithEvents Button29 As System.Windows.Forms.Button
    Friend WithEvents Button30 As System.Windows.Forms.Button
    Friend WithEvents Button31 As System.Windows.Forms.Button
    Friend WithEvents Button32 As System.Windows.Forms.Button
    Friend WithEvents Button33 As System.Windows.Forms.Button
    Friend WithEvents Button34 As System.Windows.Forms.Button
    Friend WithEvents Button35 As System.Windows.Forms.Button
    Friend WithEvents Button36 As System.Windows.Forms.Button
    Friend WithEvents Button37 As System.Windows.Forms.Button
    Friend WithEvents Button38 As System.Windows.Forms.Button
    Friend WithEvents Button39 As System.Windows.Forms.Button
    Friend WithEvents Button40 As System.Windows.Forms.Button
    Friend WithEvents Button41 As System.Windows.Forms.Button
    Friend WithEvents Button42 As System.Windows.Forms.Button
    Friend WithEvents Button43 As System.Windows.Forms.Button
    Friend WithEvents Button44 As System.Windows.Forms.Button
    Friend WithEvents Button45 As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents Button46 As System.Windows.Forms.Button

End Class
